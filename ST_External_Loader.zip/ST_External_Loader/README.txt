- staffbesting.store && .gg/staffbesting -

-- STEPS --
[  1  ] - Open Game (VALORANT)
[  2  ] - Open "ST_External_Loader.exe"
[  3  ] - Resolution: You need do "WindowedFullScreen"
[  4  ] - MENU KEY: INSERT!

-- Driver Error Fix  -- 
- Install Windows 10
- Don't Use in netcafe
- Disable Core Isolation (hvci)
- Disable FACEIT and EAC Anti Cheat
- Make sure all AV, Defender turn off
- Install "All runtimes" in Requirements file
