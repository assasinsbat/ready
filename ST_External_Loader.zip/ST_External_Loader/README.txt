staffbesting.store @ discord.gg/staffbesting

Resolution : Windowed Full Screen
Disable Defender && only Windows 10 working



