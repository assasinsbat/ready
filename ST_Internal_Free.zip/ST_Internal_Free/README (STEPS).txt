- staffbesting.store && .gg/staffbesting1

- Disable FACEIT and EAC Anti Cheat
- Make sure all AV, Defender turn off

-- STEPS --
[  1  ] - Open Game
[  2  ] - Open the "ST_Internal_Loader(V15)"
[  3  ] - Select the Start Cheat in the Loader 
[  4  ] - MENU KEY: INSERT








