@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"

set "MODE=check"
set "AUTOYES=0"
set "NOPAUSE=0"
if "%~1"=="" goto :args
for %%A in (%*) do (
  if /i "%%~A"=="fix"     set "MODE=fix"
  if /i "%%~A"=="yes"     set "AUTOYES=1"
  if /i "%%~A"=="nopause" set "NOPAUSE=1"
  if /i "%%~A"=="help"    goto :help
  if /i "%%~A"=="/?"      goto :help
)
:args

if /i "%MODE%"=="fix" (mode con: cols=46 lines=18 >nul 2>&1) else (mode con: cols=46 lines=8 >nul 2>&1)
powershell -NoProfile -EncodedCommand QQBkAGQALQBUAHkAcABlACAALQBOAGEAbQBlACAAVwAgAC0ATgBhAG0AZQBzAHAAYQBjAGUAIABOACAALQBNAGUAbQBiAGUAcgBEAGUAZgBpAG4AaQB0AGkAbwBuACAAJwBbAEQAbABsAEkAbQBwAG8AcgB0ACgAIgBrAGUAcgBuAGUAbAAzADIALgBkAGwAbAAiACkAXQBwAHUAYgBsAGkAYwAgAHMAdABhAHQAaQBjACAAZQB4AHQAZQByAG4AIABJAG4AdABQAHQAcgAgAEcAZQB0AEMAbwBuAHMAbwBsAGUAVwBpAG4AZABvAHcAKAApADsAWwBEAGwAbABJAG0AcABvAHIAdAAoACIAdQBzAGUAcgAzADIALgBkAGwAbAAiACkAXQBwAHUAYgBsAGkAYwAgAHMAdABhAHQAaQBjACAAZQB4AHQAZQByAG4AIABpAG4AdAAgAEcAZQB0AFcAaQBuAGQAbwB3AEwAbwBuAGcAKABJAG4AdABQAHQAcgAgAGgALABpAG4AdAAgAGkAKQA7AFsARABsAGwASQBtAHAAbwByAHQAKAAiAHUAcwBlAHIAMwAyAC4AZABsAGwAIgApAF0AcAB1AGIAbABpAGMAIABzAHQAYQB0AGkAYwAgAGUAeAB0AGUAcgBuACAAaQBuAHQAIABTAGUAdABXAGkAbgBkAG8AdwBMAG8AbgBnACgASQBuAHQAUAB0AHIAIABoACwAaQBuAHQAIABpACwAaQBuAHQAIAB2ACkAOwBbAEQAbABsAEkAbQBwAG8AcgB0ACgAIgB1AHMAZQByADMAMgAuAGQAbABsACIAKQBdAHAAdQBiAGwAaQBjACAAcwB0AGEAdABpAGMAIABlAHgAdABlAHIAbgAgAGIAbwBvAGwAIABTAGUAdABMAGEAeQBlAHIAZQBkAFcAaQBuAGQAbwB3AEEAdAB0AHIAaQBiAHUAdABlAHMAKABJAG4AdABQAHQAcgAgAGgALAB1AGkAbgB0ACAAYwAsAGIAeQB0AGUAIABhACwAdQBpAG4AdAAgAGYAKQA7ACcACgAkAGgAPQBbAE4ALgBXAF0AOgA6AEcAZQB0AEMAbwBuAHMAbwBsAGUAVwBpAG4AZABvAHcAKAApAAoAaQBmACgAJABoACAALQBuAGUAIABbAEkAbgB0AFAAdAByAF0AOgA6AFoAZQByAG8AKQB7ACQAZQA9AFsATgAuAFcAXQA6ADoARwBlAHQAVwBpAG4AZABvAHcATABvAG4AZwAoACQAaAAsAC0AMgAwACkAOwBbAHYAbwBpAGQAXQBbAE4ALgBXAF0AOgA6AFMAZQB0AFcAaQBuAGQAbwB3AEwAbwBuAGcAKAAkAGgALAAtADIAMAAsACgAJABlACAALQBiAG8AcgAgADAAeAA4ADAAMAAwADAAKQApADsAWwB2AG8AaQBkAF0AWwBOAC4AVwBdADoAOgBTAGUAdABMAGEAeQBlAHIAZQBkAFcAaQBuAGQAbwB3AEEAdAB0AHIAaQBiAHUAdABlAHMAKAAkAGgALAAwACwAMgAwADAALAAyACkAfQA= >nul 2>&1

set "PASSARG="
if /i "%MODE%"=="fix" set "PASSARG=fix"
if "%AUTOYES%"=="1" set "PASSARG=%PASSARG% yes"
fltmc >nul 2>&1
if errorlevel 1 (
  if defined PASSARG (
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -ArgumentList '%PASSARG%' -Verb RunAs"
  ) else (
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  )
  exit /b 1
)

set /a F=0
cls

set "V_BUILD=unknown"
set "C_BUILD=Gray"
set "BUILD="
set "DISP="
for /f "tokens=2,*" %%A in ('reg query "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion" /v CurrentBuild 2^>nul ^| findstr /i "CurrentBuild"') do set "BUILD=%%B"
for /f "tokens=2,*" %%A in ('reg query "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion" /v DisplayVersion 2^>nul ^| findstr /i "DisplayVersion"') do set "DISP=%%B"
if defined BUILD (
  set /a B=BUILD 2>nul
  set "V_BUILD=!B! !DISP!"
)

set "SB="
for /f "usebackq delims=" %%A in (`powershell -NoProfile -Command "try{[string](Confirm-SecureBootUEFI)}catch{'na'}"`) do set "SB=%%A"
set "V_SB=n/a"
set "C_SB=Yellow"
if /i "!SB!"=="True" set "V_SB=on"
if /i "!SB!"=="True" set "C_SB=Red"
if /i "!SB!"=="True" set /a F+=1
if /i "!SB!"=="False" set "V_SB=off"
if /i "!SB!"=="False" set "C_SB=Green"

set "TPM="
for /f "usebackq delims=" %%A in (`powershell -NoProfile -Command "$t=Get-CimInstance -Namespace root/cimv2/security/microsofttpm -ClassName Win32_Tpm -EA 0; if($t){[string](($t.SpecVersion -split ',')[0])}else{'na'}"`) do set "TPM=%%A"
if not defined TPM set "TPM=?"
set "V_TPM=!TPM!"
set "C_TPM=Red"
if /i "!TPM!"=="2.0" set "C_TPM=Green"
if /i not "!TPM!"=="2.0" set /a F+=1

set "HVCI="
for /f "usebackq delims=" %%A in (`powershell -NoProfile -Command "$d=Get-CimInstance -Namespace root/Microsoft/Windows/DeviceGuard -ClassName Win32_DeviceGuard -EA 0; if($d){ if($d.SecurityServicesRunning -contains 2){'on'}else{'off'} }else{'?'}"`) do set "HVCI=%%A"
if not defined HVCI set "HVCI=?"
set "V_HVCI=!HVCI!"
set "C_HVCI=Yellow"
if /i "!HVCI!"=="on" set "C_HVCI=Red"
if /i "!HVCI!"=="on" set /a F+=1
if /i "!HVCI!"=="off" set "C_HVCI=Green"

set "MP="
for /f "usebackq delims=" %%A in (`powershell -NoProfile -Command "$s=Get-MpComputerStatus -EA 0; if($s){ '{0} {1}' -f [int]$s.RealTimeProtectionEnabled,[int]$s.IsTamperProtected }else{'na na'}"`) do set "MP=%%A"
for /f "tokens=1,2" %%A in ("!MP!") do (
  set "RT=%%A"
  set "TP=%%B"
)
set "V_DEF=off"
set "C_DEF=Green"
if "!RT!"=="1" set "V_DEF=rt on"
if "!RT!"=="1" set "C_DEF=Red"
if "!RT!"=="1" set /a F+=1
if "!TP!"=="1" set "V_DEF=tp on"
if "!TP!"=="1" set "C_DEF=Red"
if "!TP!"=="1" set /a F+=1
if /i "!RT!"=="na" set "V_DEF=n/a"
if /i "!RT!"=="na" set "C_DEF=Yellow"

call :print
if /i "%MODE%"=="fix" goto :fix
if "%NOPAUSE%"=="0" pause >nul
if !F! GTR 0 exit /b 1
exit /b 0

:fix
echo.
if "%AUTOYES%"=="0" (
  echo   type YES to apply
  set "OK="
  set /p "OK=> "
  echo.
  if /i not "!OK!"=="YES" (
    echo  cancelled
    if "%NOPAUSE%"=="0" pause >nul
    exit /b 1
  )
)

reg add "HKLM\SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\HypervisorEnforcedCodeIntegrity" /v Enabled /t REG_DWORD /d 0 /f >nul 2>&1
if errorlevel 1 (call :act "hvci" "off" "fail") else (call :act "hvci" "off" "ok")

reg add "HKLM\SYSTEM\CurrentControlSet\Control\CI\Config" /v VulnerableDriverBlocklistEnable /t REG_DWORD /d 0 /f >nul 2>&1

reg add "HKLM\SYSTEM\CurrentControlSet\Control\CI\Policy" /v VerifiedAndReputablePolicyState /t REG_DWORD /d 0 /f >nul 2>&1
if errorlevel 1 (call :act "smart app" "off" "fail") else (call :act "smart app" "off" "ok")

powershell -NoProfile -Command "Add-MpPreference -ExclusionPath '%~dp0' -EA 0; Add-MpPreference -ExclusionProcess 'ST_Internal_Loader.exe' -EA 0; Set-MpPreference -EnableControlledFolderAccess Disabled -EA 0; Set-MpPreference -DisableRealtimeMonitoring $true -EA 0" >nul 2>&1
call :act "defender" "excl rt cfa" "done"

powershell -NoProfile -Command "Get-ChildItem -LiteralPath '%~dp0' -File -EA 0 | Unblock-File -EA 0" >nul 2>&1
call :act "loader" "unblock" "done"

echo.
echo   restart now? [y/N]
set "RB="
set /p "RB=> "
if /i "!RB!"=="y" shutdown /r /t 5
if "%NOPAUSE%"=="0" pause >nul
exit /b 0

:help
echo.
echo   %~nx0  [fix] [yes] [nopause]
echo.
exit /b 0

:print
powershell -NoProfile -Command "$r=@(@('build',$env:V_BUILD,$env:C_BUILD),@('secure boot',$env:V_SB,$env:C_SB),@('tpm',$env:V_TPM,$env:C_TPM),@('hvci',$env:V_HVCI,$env:C_HVCI),@('defender',$env:V_DEF,$env:C_DEF)); foreach($x in $r){ Write-Host ('  {0,-13} ' -f $x[0]) -NoNewline; Write-Host $x[1] -ForegroundColor $x[2] }; [Console]::ResetColor()"
exit /b 0

:act
set "L=%~1            "
set "L=!L:~0,12!"
set "V=%~2            "
set "V=!V:~0,12!"
echo   !L!  !V!  %~3
exit /b
