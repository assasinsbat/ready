- staffbesting.store && .gg/staffbesting1

- Disable FACEIT and EAC Anti Cheat
- Make sure all AV, Defender turn off

-- STEPS --
[  1  ] - Run as Administrator ToolKit
[  2  ] - Select the "Virtual Disk Driver" & Install
[  3  ] - Open Game
[  4  ] - Open the "ST_Internal_Loader(V15)"
[  5  ] - Select the Start Cheat in the Loader 
[  6  ] - MENU KEY: INSERT







