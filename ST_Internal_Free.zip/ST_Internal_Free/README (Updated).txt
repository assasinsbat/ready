- staffbesting.store && .gg/staffbesting1

- Disable FACEIT and EAC Anti Cheat
- Make sure all AV, Defender turn off

-- STEPS --
[  1  ] - Run as Administrator "ToolKit"
[  2  ] - Select the "Virtual Disk Driver (required)" in ToolKit GUI
[  3  ] - Click Install!

[  4  ] - Open Game
[  5  ] - Open the "ST_Internal_Loader(V15).exe"
[  6  ] - Select the Start Cheat in the Loader 
[  7  ] - MENU KEY: INSERT







