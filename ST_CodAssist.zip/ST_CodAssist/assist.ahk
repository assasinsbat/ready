#NoEnv
#SingleInstance, Force
#Persistent
#InstallKeybdHook
#UseHook
#KeyHistory, 0
#HotKeyInterval 1
#MaxHotkeysPerInterval 127
CoordMode, Pixel, Screen, RGB
CoordMode, Mouse, Screen

dllPath32 := A_ScriptDir "\Requirements\hyde.dll"
dllPath64 := A_ScriptDir "\Requirements\hyde64.dll"
dllPath := (A_PtrSize = 4) ? dllPath32 : dllPath64

if !DllCall("LoadLibrary", "Str", dllPath)
{
    MsgBox, Failed to load %dllPath%
    ExitApp
}

ConfigFile := A_ScriptDir "\config.ini"
IniRead, CfgSmoothing, %ConfigFile%, Settings, Smoothing, 20
IniRead, CfgTargetMode, %ConfigFile%, Settings, TargetMode, Head
IniRead, CfgPrediction, %ConfigFile%, Settings, Prediction, 0
if (CfgTargetMode != "Head" && CfgTargetMode != "Chest")
    CfgTargetMode := "Head"

OnExit, SaveConfig

PID := DllCall("GetCurrentProcessId")
Process, Priority, %PID%, High
Gui, +AlwaysOnTop
Width := 310
Gui, +LastFound
WinSet, Transparent, 235
Gui, Color, 1C1C1E
Gui, Margin, 0, 0
Gui, Font, s10 cF2F2F7 Bold, Segoe UI
Gui, Add, Progress, % "x-1 y-1 w" (Width+2) " h31 Background0E0E10 Disabled hwndHPROG"
Control, ExStyle, -0x20000, , ahk_id %HPROG%
Gui, Add, Text, % "x0 y0 w" Width " h30 BackgroundTrans Center 0x200 gGuiMove vCaption", Aim Assist
Gui, Font, s8 cEBEBF5, Segoe UI
Gui, Add, CheckBox, % "x7 y+10 w" (Width-14) "r1 +0x4000 vEnableCheckbox", Enable (ALT Key)
PredictionOpt := (CfgPrediction = "1") ? "Checked " : ""
Gui, Add, CheckBox, % "x7 y+5 w" (Width-14) "r1 +0x4000 " PredictionOpt "vEnablePredictionCheckbox", Enable Prediction
Gui, Add, Text, % "x7 y+10 w" (Width-14) "r1 +0x4000", Target Location
Gui, Add, Button, % "x7 y+5 w" (Width-200) "r1 +0x4000 gHeadshotsButton", Head
Gui, Add, Button, % "x+2+m w" (Width-200) "r1 +0x4000 gChestButton", Chest
Gui, Add, Text, % "x7 y+10 w" (Width-20) "r1 +0x4000", Smoothing (Default is 0.2)
Gui, Add, Text, % "x7 y+5 w" (Width-14) "r1 +0x4000 vSmoothingValue", % Format("{:.2f}", CfgSmoothing / 100)
Gui, Add, Slider, % "x7 y+5 w" (Width-14) "r1 +0x4000 vSmoothingSlider gUpdateSmoothing Range0-200 TickInterval10", %CfgSmoothing%
Gui, Add, Text, % "x7 y+10 w" (Width-14) "r1 +0x4000 gClose", Close
Gui, Add, Text, % "x7 y+15 w" "h5 vP"
GuiControlGet, P, Pos
H := PY + PH
Gui, -Caption
WinSet, Region, 0-0 w%Width% h%H% r10-10
Gui, Show, % "w" Width " NA x" (A_ScreenWidth - Width - 10) " y550"
EMCol := 0xc9008d
ColVn := 20
ZeroX := A_ScreenWidth / 2
TargetMode := CfgTargetMode
ZeroY := (TargetMode = "Chest") ? A_ScreenHeight / 2.12 : A_ScreenHeight / 2.08
CFovX := 40
CFovY := 40
ScanL := ZeroX - CFovX
ScanT := ZeroY - CFovY
ScanR := ZeroX + CFovX
ScanB := ZeroY + CFovY
SearchArea := 30
prevX := 0
prevY := 0
lastTime := 0
smoothing := CfgSmoothing / 100
predictionMultiplier := 2.5
guiVisible := true
Loop
{
GuiControlGet, EnableState,, EnableCheckbox
if (EnableState) {
targetFound := False
if GetKeyState("LButton", "P") or GetKeyState("RButton", "P") {
PixelSearch, AimPixelX, AimPixelY, targetX - SearchArea, targetY - SearchArea, targetX + SearchArea, targetY + SearchArea, EMCol, ColVn, Fast RGB
if (!ErrorLevel) {
targetX := AimPixelX
targetY := AimPixelY
targetFound := True
} else {
PixelSearch, AimPixelX, AimPixelY, ScanL, ScanT, ScanR, ScanB, EMCol, ColVn, Fast RGB
if (!ErrorLevel) {
targetX := AimPixelX
targetY := AimPixelY
targetFound := True
}
}
if (targetFound) {
currentTime := A_TickCount
if (lastTime != 0) {
deltaTime := (currentTime - lastTime) / 1000.0
velocityX := (targetX - prevX) / deltaTime
velocityY := (targetY - prevY) / deltaTime
}
prevX := targetX
prevY := targetY
lastTime := currentTime
GuiControlGet, PredictionEnabled,, EnablePredictionCheckbox
if (PredictionEnabled && deltaTime != 0) {
PredictedX := targetX + Round(velocityX * predictionMultiplier * deltaTime)
PredictedY := targetY + Round(velocityY * predictionMultiplier * deltaTime)
} else {
PredictedX := targetX
PredictedY := targetY
}
AimX := PredictedX - ZeroX
AimY := PredictedY - ZeroY
DllCall("mouse_event", uint, 1, int, Round(AimX * smoothing), int, Round(AimY * smoothing), uint, 0, int, 0)
}
}
}
Sleep, 10
}
HeadshotsButton:
ZeroY := A_ScreenHeight / 2.08
TargetMode := "Head"
Return
ChestButton:
ZeroY := A_ScreenHeight / 2.12
TargetMode := "Chest"
Return
GuiMove:
PostMessage, 0xA1, 2
return
UpdateSmoothing:
GuiControlGet, SliderVal,, SmoothingSlider
smoothing := SliderVal / 100
GuiControl,, SmoothingValue, % Format("{:.2f}", smoothing)
Return
SaveConfig:
GuiControlGet, CurSlider,, SmoothingSlider
GuiControlGet, CurPrediction,, EnablePredictionCheckbox
IniWrite, %CurSlider%, %ConfigFile%, Settings, Smoothing
IniWrite, %TargetMode%, %ConfigFile%, Settings, TargetMode
IniWrite, %CurPrediction%, %ConfigFile%, Settings, Prediction
if (A_EventInfo = "Reload")
    Reload
ExitApp
Alt::
GuiControlGet, EnableState,, EnableCheckbox
GuiControl,, EnableCheckbox, % !EnableState
toggle := EnableState
if (toggle) {
SoundBeep, 300, 100
}
Return
Insert::
if (guiVisible) {
Gui, Hide
guiVisible := false
} else {
Gui, Show
guiVisible := true
}
Return
GuiClose:
ExitApp
Return
Close:
ExitApp
f9::Reload
