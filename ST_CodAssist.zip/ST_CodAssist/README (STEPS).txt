━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  REQUIREMENTS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
[  1  ] - Install "AutoHotkey_1.1.37.02_setup.exe" (included in this folder).
[  2  ] - This is an .AHK script - it will not run without AutoHotkey v1.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  DISPLAY SETTINGS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
[  1  ] - Set the display mode to "Fullscreen Borderless".

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  INTERFACE SETTINGS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
[  1  ] - Set "Colorblind Mode" to "Custom" first - this unlocks the custom enemy color field used in the next step.
[  2  ] - Set enemy color to c9008d (Magenta).
[  3  ] - Set "Player Names" to "Icon Only".
[  4  ] - Set "Damage-Based Hit Markers" to "OFF".
[  5  ] - Keep your crosshair color away from pink/magenta/purple (e.g. use cyan, green, or white) - a matching crosshair color can get
          picked up as a false target near the center of the screen.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  MAIN STEPS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
[  1  ] - Run "assist.ahk" (double-click it, or right-click > Run Script).
[  2  ] - Start the game and set your interface/display settings as above.
[  3  ] - Choose "Head" or "Chest" as the target location in the overlay.
[  4  ] - Adjust the smoothing slider if needed (default is 0.20).
[  5  ] - Hold Left Click or Right Click to aim while "Enable" is checked.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  HOTKEYS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
[  Alt    ] - Toggle aim on/off.
[  Insert ] - Show/hide the overlay window.
[  F9     ] - Reload the script.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  SETTINGS MEMORY
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
[  +  ] - Target location, smoothing, and prediction are saved automatically
[  +  ] - to "config.ini" next to the script, and reload the next time you run it.
[  +  ] - "Enable" always starts OFF for safety, even if it was on last time.
