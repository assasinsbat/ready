staffbesting.store && .gg/staffbesting
--------------------------------------
[ 1 ] - Open the Counter-Strike 2
[ 2 ] - Open the "CSGO2 Injector.exe" Loader
[ 3 ] - Select the Inject in the Injector
[ 4 ] - Select the CS:GO in the Injector
[ 5 ] - In the dll name section, type "staffbesting-cs2.dll" enter the name and click on the enter button