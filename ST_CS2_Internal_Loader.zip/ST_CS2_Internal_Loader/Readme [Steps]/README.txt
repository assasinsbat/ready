staffbesting.store && .gg/staffbesting

[ 1 ] - Open the Counter-Strike-2
[ 2 ] - Open the Administrator "CSGO2.exe" Loader
[ 3 ] - Select the STAFFBESTING.dll
[ 4 ] - Enter Game...
