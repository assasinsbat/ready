staffbesting.store && .gg/staffbesting
--------------------------------------
[ 1 ] - Open the Counter-Strike 2
[ 2 ] - Open the "CSGO2 Injector.exe" Loader
[ 3 ] - Select the cs2_module.dll