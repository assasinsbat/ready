📌 Links:
staffbesting.store
.gg/staffbesting1

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  MAIN STEPS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
[  1  ] - Start the game.
[  2  ] - Set the display mode to "Windowed Fullscreen".
[  3  ] - Run "ST_TriggerBot.exe".
[  4  ] - Ensure "Enemy Fresnel Color" is set to Purple.
[  5  ] - Trigger Key: Left Alt

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  ERROR FIXES
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  ⚠ Program Not Starting — Hyper-V Required
  ─────────────────────────────────────────
[  1  ] - Open "Windows Features" (search in Start Menu).
[  2  ] - Check "Hyper-V" and all its sub-components.
[  3  ] - Click OK and restart your computer.