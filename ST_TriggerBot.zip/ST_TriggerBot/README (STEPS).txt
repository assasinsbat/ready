staffbesting.store & .gg/staffbesting1

- STEPS -
[  1  ] - Start Game
[  2  ] - Change your game’s display mode to "Windowed Fullscreen"
[  3  ] - Run "ST_TriggerBot.exe"
[  4  ] - Ensure the "Enemy Fresnel Color" is set to Purple.
[  5  ] - Trigger Key: "LEFT ALT"

- IMPORTANT: Hyper-V Requirement
  If the program doesn't start, please verify that Hyper-V is enabled:
  1. Open "Windows Features" (search in Start Menu)
  2. Check "Hyper-V" and all its sub-components
  3. Click OK and restart your computer


