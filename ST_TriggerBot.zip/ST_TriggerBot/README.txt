staffbesting.store & .gg/staffbesting

- STEPS -
[ 1 ] - Launch the Discord Overlay.
[ 1 ] - Start Valorant.
[ 1 ] - Run "ST_TriggerBot.exe".

Note: Please ensure these actions are performed without altering the resolution settings.