
staffbesting.store & .gg/staffbesting

 STEPS
[ 1 ] - Open the Discord Overlay
[ 2 ] - Open the Valorant
[ 3 ] - and Open the "ST_TriggerBot.exe"