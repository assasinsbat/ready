staffbesting.store & .gg/staffbesting1

- STEPS -
[  1  ] - Start Game
[  2  ] - Do Game Resolution "Windowed Full Screen"
[  3  ] - Run "ST_TriggerBot.exe"
[  4  ] - Enemy Color "Purple"
[  5  ] - Select TriggerBot mode (choose: Auto or Hotkey)
