staffbesting.store & .gg/staffbesting1

- STEPS -
[  1  ] - Start Game
[  2  ] - Run "ST_TriggerBot.exe"
[  3  ] - Enemy Color "Purple"
[  4  ] - Select TriggerBot mode (choose: Auto or Hotkey)
