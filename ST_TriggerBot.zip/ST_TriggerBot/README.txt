staffbesting.store & .gg/staffbesting1

- STEPS -
[  1  ] - Launch the Discord Overlay
[  2  ] - Start Valorant
[  3  ] - Run "ST_TriggerBot.exe"
[  4  ] - Enemy Color "Purple"

Note: Please ensure these actions are performed without altering the resolution settings.
Note: If you get "Unable to acquire a new resolution. Try restarting the program" use 1920x1080 and try again