━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  REQUIREMENTS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
[  1  ] - Install "AutoHotkey_1.1.37.02_setup.exe" (included in this folder).
[  2  ] - This is an .AHK script - it will not run without AutoHotkey v1.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  DISPLAY SETTINGS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
[  1  ] - Set the display mode to "Fullscreen Borderless".

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  INTERFACE SETTINGS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
[  1  ] - Set enemy color to EA00FF.
[  2  ] - Set "High Contrast Mode" to "Full Color".
[  3  ] - Set "High Contrast Mode" to only show Enemies.
[  4  ] - In "Gameplay HUD", turn OFF "Zombie Healthbars" and "Damage Numbers".
[  5  ] - In "Gameplay HUD", turn OFF "Enable Pack-a-Punch Camo".
[  6  ] - In "Gameplay HUD", turn OFF "Damage-Based Hit Markers".
[  7  ] - Keep your crosshair color away from pink/magenta (e.g. use cyan, green, or white) - a matching crosshair color can get
          picked up as a false target near the center of the screen.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  GRAPHIC SETTINGS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
[  1  ] - In "View", turn ON "Arachnophobia Mode".
[  2  ] - In "View", set "FOV" to 120.
[  !  ] - Certain camos will not work with this aimbot (any pink camos) -
          avoid equipping them while the assist is active.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  MAIN STEPS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
[  1  ] - Run "assist.ahk" (double-click it, or right-click > Run Script).
[  2  ] - Start the game and set your interface/display settings as above.
[  5  ] - Hold Left Click or Right Click to aim while "Enable" is checked.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  HOTKEYS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
[  Alt    ] - Toggle aim on/off.
[  Insert ] - Show/hide the overlay window.
[  F9     ] - Reload the script.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  SETTINGS MEMORY
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
[  +  ] - Aim level and smoothing are saved automatically
[  +  ] - to "config.ini" next to the script, and reload the next time you run it.
[  +  ] - "Enable" always starts OFF for safety, even if it was on last time.
