#NoEnv
#SingleInstance, Force
#Persistent
#InstallKeybdHook
#UseHook
#KeyHistory, 0
#HotKeyInterval 1
#MaxHotkeysPerInterval 127
CoordMode, Pixel, Screen, RGB
CoordMode, Mouse, Screen
PID := DllCall("GetCurrentProcessId")
Process, Priority, %PID%, High

dllPath32 := A_ScriptDir "\Requirements\hyde.dll"
dllPath64 := A_ScriptDir "\Requirements\hyde64.dll"
dllPath := (A_PtrSize = 4) ? dllPath32 : dllPath64

if !DllCall("LoadLibrary", "Str", dllPath)
{
    MsgBox, Failed to load %dllPath%
    ExitApp
}

ConfigFile := A_ScriptDir . "\config.ini"

EMCol := 0xb528c0
ColVn := 30
ZeroX := A_ScreenWidth / 2
CFovX := 170
CFovY := 170
SearchArea := 40

prevX := 0
prevY := 0
lastTime := 0
GuiVisible := True

IniRead, smoothing, %ConfigFile%, Settings, Smoothing, 0.41
IniRead, ZeroY, %ConfigFile%, Settings, ZeroY, % Round(A_ScreenHeight / 2.09)

ScanL := ZeroX - CFovX
ScanT := ZeroY - CFovY
ScanR := ZeroX + CFovX
ScanB := ZeroY + CFovY

Gui, +AlwaysOnTop
Width := 310
Gui, +LastFound
WinSet, Transparent, 235
Gui, Color, 1C1C1E
Gui, Margin, 0, 0

Gui, Font, s10 cF2F2F7 Bold, Segoe UI
Gui, Add, Progress, % "x-1 y-1 w" (Width+2) " h31 Background0E0E10 Disabled hwndHPROG"
Control, ExStyle, -0x20000, , ahk_id %HPROG%
Gui, Add, Text, % "x0 y0 w" Width " h30 BackgroundTrans Center 0x200 gGuiMove vCaption", Zombies Aim Assist

Gui, Font, s8 cEBEBF5, Segoe UI
Gui, Add, CheckBox, % "x7 y+10 w" (Width-14) "r1 +0x4000 vEnableCheckbox", Enable (ALT key)

Gui, Add, Text, % "x7 y+10 w" (Width-100) "r1 +0x4000", Smoothing
Gui, Add, Text, % "x+m w" (Width-14) "r1 +0x4000 vSmoothingValue", %smoothing%
Gui, Add, Button, % "x7 y+5 w" (Width-275) "r1 +0x4000 gDecreaseSmoothing", -
Gui, Add, Button, % "x+2+m w" (Width-275) "r1 +0x4000 gIncreaseSmoothing", +

Gui, Add, Text, % "x7 y+10 w" (Width-100) "r1 +0x4000", Aim Level (ZeroY)
Gui, Add, Text, % "x+m w" (Width-14) "r1 +0x4000 vZeroYValue", %ZeroY%
Gui, Add, Button, % "x7 y+5 w" (Width-275) "r1 +0x4000 gDecreaseZeroY", -
Gui, Add, Button, % "x+2+m w" (Width-275) "r1 +0x4000 gIncreaseZeroY", +

Gui, Add, Text, % "x7 y+10 w" (Width-14) "r1 +0x4000 gClose", Close
Gui, Add, Text, % "x7 y+15 w" "h5 vP"
GuiControlGet, P, Pos
H := PY + PH
Gui, -Caption
WinSet, Region, 0-0 w%Width% h%H% r6-6

Gui, Show, % "w" Width " NA" " x" (A_ScreenWidth - Width) "x10 y550"

Loop
{
    GuiControlGet, EnableState,, EnableCheckbox
    if (EnableState) {
        targetFound := False

        if GetKeyState("LButton", "P") or GetKeyState("RButton", "P") {
            PixelSearch, AimPixelX, AimPixelY, targetX - SearchArea, targetY - SearchArea, targetX + SearchArea, targetY + SearchArea, EMCol, ColVn, Fast RGB
            if (!ErrorLevel) {
                targetX := AimPixelX
                targetY := AimPixelY
                targetFound := True
            } else {
                PixelSearch, AimPixelX, AimPixelY, ScanL, ScanT, ScanR, ScanB, EMCol, ColVn, Fast RGB
                if (!ErrorLevel) {
                    targetX := AimPixelX
                    targetY := AimPixelY
                    targetFound := True
                }
            }

            if (targetFound) {
                currentTime := A_TickCount

                if (lastTime != 0) {
                    deltaTime := (currentTime - lastTime) / 1000.0
                    velocityX := (targetX - prevX) / deltaTime
                    velocityY := (targetY - prevY) / deltaTime
                }

                prevX := targetX
                prevY := targetY
                lastTime := currentTime

                GuiControlGet, PredictionEnabled,, EnablePredictionCheckbox
                if (PredictionEnabled && deltaTime != 0) {
                    PredictedX := targetX + Round(velocityX * predictionMultiplier * deltaTime)
                    PredictedY := targetY + Round(velocityY * predictionMultiplier * deltaTime)
                } else {
                    PredictedX := targetX
                    PredictedY := targetY
                }

                AimX := PredictedX - ZeroX
                AimY := PredictedY - ZeroY
                DllCall("mouse_event", uint, 1, int, Round(AimX * smoothing), int, Round(AimY * smoothing), uint, 0, int, 0)
            }
        }
    }
    Sleep, 10
}

GuiMove:
    PostMessage, 0xA1, 2
    return

IncreaseSmoothing:
    smoothing += 0.01
    if (smoothing > 2)
        smoothing := 2
    GuiControl,, SmoothingValue, %smoothing%
    IniWrite, %smoothing%, %ConfigFile%, Settings, Smoothing
    Return

DecreaseSmoothing:
    smoothing -= 0.01
    if (smoothing < 0.01)
        smoothing := 0.01
    GuiControl,, SmoothingValue, %smoothing%
    IniWrite, %smoothing%, %ConfigFile%, Settings, Smoothing
    Return

IncreaseZeroY:
    ZeroY += 1
    ScanT := ZeroY - CFovY
    ScanB := ZeroY + CFovY
    GuiControl,, ZeroYValue, %ZeroY%
    IniWrite, %ZeroY%, %ConfigFile%, Settings, ZeroY
    Return

DecreaseZeroY:
    ZeroY -= 1
    ScanT := ZeroY - CFovY
    ScanB := ZeroY + CFovY
    GuiControl,, ZeroYValue, %ZeroY%
    IniWrite, %ZeroY%, %ConfigFile%, Settings, ZeroY
    Return

Paused := False
Alt::
    GuiControlGet, EnableState,, EnableCheckbox
    GuiControl,, EnableCheckbox, % !EnableState
    toggle := EnableState
    if (toggle) {
        SoundBeep, 300, 100
    }
Return

Insert::
    GuiVisible := !GuiVisible
    if (GuiVisible)
        Gui, Show
    else
        Gui, Hide
Return

OnExit:
GuiClose:
    ExitApp
    Return

Close:
ExitApp

f9::Reload
