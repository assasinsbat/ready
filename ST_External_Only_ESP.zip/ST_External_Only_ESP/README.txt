- staffbesting.store && .gg/staffbesting -

- Working Hvci On & Off
- Disable FACEIT and EAC Anti Cheat
- Make sure all AV, Defender turn off
- Resolution: "WindowedFullScreen"

-- STEPS --
[  1  ] - Open "ST_External_Loader"
[  2  ] - Open Game
[  3  ] - Menu Key: Insert

