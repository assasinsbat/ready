- Website: staffbesting.store
- Discord: .gg/staffbesting1

- Disable FACEIT & EAC Anti-Cheat
- Turn off all Antivirus & Windows Defender

-- STEPS --
1. Open Game
2. Run Loader
3. Click "Start Cheat" in Loader
4. Menu Key: INSERT

-- NOTES --
• Python error? → Uninstall Python or click "OK"
• VAN error? → Reinstall Windows, then try again