- staffbesting.store && .gg/staffbesting1

- Disable FACEIT and EAC Anti Cheat
- Make sure all AV, Defender turn off

[  1  ] - Open Game
[  2  ] - Open the "ST_SkinChanger.exe"
[  3  ] - Select the Start Cheat in the Loader 
[  4  ] - MENU KEY: INSERT







