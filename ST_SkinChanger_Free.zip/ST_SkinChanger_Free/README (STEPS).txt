📌 Links:
staffbesting.store
.gg/staffbesting1

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  MAIN STEPS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
[  1  ] - Open the game.
[  2  ] - Run the loader.
[  3  ] - Click "Start Cheat" in the loader.
[  4  ] - Menu Key: Insert

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  NOTES
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
[  +  ] - Python error? → Uninstall Python or click "OK".
[  +  ] - VAN error? → Reinstall Windows, then try again.