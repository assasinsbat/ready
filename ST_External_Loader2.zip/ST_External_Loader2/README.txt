-- staffbesting.store & discord.gg/staffbesting --

[ 1 ] Open the "ST_External_Loader[2].exe"
[ 2 ] 
[ 2 ] Finally Open the Game , Set the Resolution to Windowed Full Screen
[ 3 ] Menu Key: Insert

[ ! ] If there is bending in the menu and in Esp, do "alt+tab" once
[ ! ] If the Driver Loaded error occurs, turn on the loader again

