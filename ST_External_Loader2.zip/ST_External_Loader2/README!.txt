-- staffbesting.store & discord.gg/staffbesting --

Resolution: Windowed Full Screen

[ 1 ] Open the "ST_External_Loader[2].exe"
[ 2 ] Open the Game
[ 3 ] Menu Key: Insert

[ ! ] If there is bending in the menu and in Esp, do "alt+tab" once

-- Driver Error Fix  -- 
- Install Windows 10
- Don't Use in netcafe
- Disable Core Isolation (hvci)
- Disable FACEIT and EAC Anti Cheat
- Make sure all AV, Defender turn off
- Install "All runtimes" in Requirements file

