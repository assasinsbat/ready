STEPS!

1 - Open the Counter Strike 2
2 - Resolution Windowed Full Screen
3 - While in the lobby Open "ST_CS2_Loader.exe"
4 - Menu Button INSERT
5 - Turn off Team Check Feature while in Deathmatch [ To prevent her from assigning esp to her own team members ]