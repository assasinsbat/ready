━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  MAIN STEPS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
[  1  ] - Start the game.
[  2  ] - Make sure the game resolution is set to "Windowed Full Screen".
[  3  ] - Run "ST_Assist.exe".
[  4  ] - Make sure Enemy Fresnel is set to "Purple".