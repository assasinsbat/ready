staffbesting.store & .gg/staffbesting1

- STEPS -
[  1  ] - Start Game
[  2  ] - Make sure Game Resolution "Windowed Full Screen"
[  3  ] - Run "ST_Assist.exe"
[  4  ] - Make sure Enemy Fresnel "Purple"
