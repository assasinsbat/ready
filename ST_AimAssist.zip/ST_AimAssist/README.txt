staffbesting.store & .gg/staffbesting1

- STEPS -
[  1  ] - Start Game
[  2  ] - Do Game Resolution "Windowed Full Screen"
[  3  ] - Run "ST_AimAssist.exe"
[  4  ] - Enemy Color "Purple"
