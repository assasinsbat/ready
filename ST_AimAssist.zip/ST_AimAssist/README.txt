staffbesting.store & .gg/staffbesting1

- STEPS -
[  1  ] - Start Game
[  2  ] - Run "ST_AimAssist.exe"
[  3  ] - Enemy Color "Purple"
