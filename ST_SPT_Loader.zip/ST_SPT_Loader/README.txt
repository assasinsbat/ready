
staffbesting.store && .gg/staffbesting

- STEPS:
1 - Open the ST_SPT_Loader.exe
2 - Open the Game [SPT-Tarkov]
3 - Select the Start Cheat
4 - Enter the letter of your SPT Tarkov directory
4 - After the operations are completed, you can turn off the loader

Menu Key: ALT

How to use SPT Tarkov? and other questions
- https://hub.sp-tarkov.com/faq/